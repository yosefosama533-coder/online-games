# نسخة تشخيص Online Games

هذا المشروع يحتوي مسارين:
- `productionRelease`: النسخة الرسمية كما هي، بمعرّف الحزمة `com.onlinegames.official`.
- `diagnosticDebug`: تطبيق منفصل بمعرّف `com.onlinegames.official.diagnostic` يفتح الموقع داخل Android WebView ويعرض حالة التحميل وأخطاء الشبكة/محرك العرض على الشاشة ويسجلها تحت الوسم `OG_DIAGNOSTIC`.

نسخة التشخيص ليست بديلًا للنشر على Google Play ولا تغيّر Firebase أو ملفات الموقع. الغرض منها عزل مشكلة تشغيل TWA: إذا عمل الموقع في نسخة التشخيص، نركز على TWA/Chrome؛ وإذا فشل، ستظهر رسالة الخطأ في الشريط العلوي.
