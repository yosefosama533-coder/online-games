# Online Games Android

- Package: `com.onlinegames.official`
- Version code: `5`
- Version name: `1.0.1`
- Website: `https://yosefosama533-coder.github.io/online-games/`

This build uses Android WebView instead of Trusted Web Activity because the TWA launch path failed on multiple test devices while the WebView diagnostic build successfully loaded the website. Website and Firebase project data are not modified.

Before publishing, test sign-in, navigation, forms, media uploads, and any external authentication flows on physical Android devices. WebView behavior can differ from Chrome/TWA, especially for Google OAuth and payment redirects.
