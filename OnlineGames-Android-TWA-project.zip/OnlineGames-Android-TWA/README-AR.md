# Online Games — Android TWA project scaffold

اسم التطبيق: Online Games  
اسم الحزمة: `com.onlinegames.yousef`  
رابط الموقع: `https://yosefosama533-coder.github.io/online-games/`

## الحالة الحالية
- تم إنشاء هيكل مشروع Android Studio منفصل.
- يستخدم Trusted Web Activity عبر Android Browser Helper 2.8.0.
- تم نسخ ملفات PWA المرفقة كما هي إلى `site-files/`.
- تم إنشاء أيقونات Android من `icon.svg`.
- لم يتم بناء APK أو AAB بعد؛ يلزم Android Studio/Android SDK وGradle.
- ملف `assetlinks.json.template` غير صالح للنشر قبل استبدال قيمة SHA-256 ببصمة شهادة التوقيع الفعلية.

## الخطوات التالية
1. افتح المجلد `OnlineGames-Android-TWA` في Android Studio.
2. ثبّت Android SDK Platform 36 وBuild Tools المطلوبة إذا طلب Android Studio ذلك.
3. نفّذ Gradle Sync ثم Build > Generate Signed Bundle / APK.
4. أنشئ Upload key خاصًا بك واحتفظ بملف keystore وكلمة مروره في مكان آمن ولا ترسلهما لأي شخص.
5. بعد تفعيل Play App Signing ورفع أول AAB، انسخ SHA-256 من **App signing key certificate** في Play Console إلى ملف `assetlinks.json` (وليس Upload key certificate عند اعتماد شهادة توقيع Google Play).
6. ارفع الملف النهائي إلى المستودع بحيث يصبح متاحًا على:
   `https://yosefosama533-coder.github.io/.well-known/assetlinks.json`
   ملاحظة: لأن GitHub Pages يخدم الموقع من مسار `/online-games/` على النطاق نفسه، يجب أن يكون ملف التحقق على جذر النطاق `yosefosama533-coder.github.io`، وليس داخل مجلد `online-games` فقط. إذا كان المستودع مشروعًا وليس مستودع المستخدم الرئيسي، ستحتاج إعداد استضافة على الجذر أو نطاق مخصص لدعم TWA والتحقق.

## ملاحظة توافق مهمة
هذا الهيكل لا يثبت بعد أن Google/Facebook sign-in أو Firebase web push يعملان داخل نسخة Android النهائية. يجب اختبار تسجيل الدخول والإشعارات على جهاز Android قبل اعتماد الإصدار.
